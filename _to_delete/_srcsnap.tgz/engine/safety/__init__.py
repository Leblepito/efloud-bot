"""Safety layer — crash recovery, circuit breakers, position guards, mainnet guards."""

from .breaker import CircuitBreaker, BreakerState, BreakerStatus
from .state import StateStore, reconcile_positions, ReconciliationError
from .guard import (
    retry_with_backoff, RateLimiter, RetryExhausted,
    validate_kline_freshness, validate_kline_integrity, StaleDataError,
    MainnetGuard, mask_secret,
)
from .position_guard import (
    PositionGuard, PositionCheckResult, PauseConfig, PauseGateDecision,
    load_pause_config, cleanup_orphan_hedges,
)
from .orphan_protection import (
    OrphanProtectionConfig, CoverageStatus, ProtectionAction,
    OrphanProtector, load_orphan_protection_config,
)

__all__ = [
    "CircuitBreaker", "BreakerState", "BreakerStatus",
    "StateStore", "reconcile_positions", "ReconciliationError",
    "retry_with_backoff", "RateLimiter", "RetryExhausted",
    "validate_kline_freshness", "validate_kline_integrity", "StaleDataError",
    "MainnetGuard", "mask_secret",
    "PositionGuard", "PositionCheckResult", "PauseConfig", "PauseGateDecision",
    "load_pause_config", "cleanup_orphan_hedges",
    "OrphanProtectionConfig", "CoverageStatus", "ProtectionAction",
    "OrphanProtector", "load_orphan_protection_config",
]
